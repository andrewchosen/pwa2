/*  
	RE{FACTOR}
	Author: Andrew Lancaster
	Date: 5/7/2015
*/

$(document).ready(function($){
	
	
	
	
		

	
})(jQuery); // end private scope




